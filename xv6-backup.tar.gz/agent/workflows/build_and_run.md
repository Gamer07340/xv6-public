---
description: Build and run the project using make qemu
---

1. Run the build and emulator:
   ```bash
   make qemu
   ```
