echo hello from script
ls
